@echo off
setlocal
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0preset2_autostart.ps1" -Action Install
set "result=%errorlevel%"
echo.
pause
exit /b %result%

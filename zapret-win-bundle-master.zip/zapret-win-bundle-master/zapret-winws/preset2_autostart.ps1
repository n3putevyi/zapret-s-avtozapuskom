﻿param(
    [ValidateSet('Install', 'Remove')]
    [string]$Action = 'Install'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$ServiceName = 'Zapret2Auto'
$Root = $PSScriptRoot
$EnginePath = [System.IO.Path]::GetFullPath((Join-Path $Root 'winws2.exe'))
$PresetPath = Join-Path $Root 'preset2_example.cmd'

function Test-EngineCommandLine {
    param([string]$Line)

    if ([string]::IsNullOrWhiteSpace($Line)) { return $false }
    $escaped = [regex]::Escape($EnginePath)
    $pattern = '^\s*(?:"' + $escaped + '"|' + $escaped + ')(?=\s|$)'
    return [regex]::IsMatch($Line, $pattern, [System.Text.RegularExpressions.RegexOptions]::IgnoreCase)
}

function Get-LocalEngineProcess {
    @(Get-CimInstance Win32_Process -Filter "Name='winws2.exe'" |
        Where-Object { $_.ExecutablePath -and $_.ExecutablePath -ieq $EnginePath })
}

function Start-Preset {
    $arguments = '/d /c ""{0}""' -f $PresetPath
    Start-Process -FilePath $env:ComSpec -ArgumentList $arguments -WorkingDirectory $Root
}

function Get-NativeService {
    Get-CimInstance Win32_Service -Filter "Name='$ServiceName'"
}

try {
    $identity = [System.Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object System.Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([System.Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Нужны права администратора. Нажми правой кнопкой на CMD-файле и выбери «Запуск от имени администратора».'
    }

    $existing = Get-NativeService

    if ($Action -eq 'Remove') {
        if (-not $existing) {
            Write-Host 'Служба Zapret2Auto не установлена.' -ForegroundColor Yellow
            exit 0
        }
        if (-not (Test-EngineCommandLine $existing.PathName)) {
            throw 'Служба Zapret2Auto указывает на другую папку. Запусти удаление из папки, где она была установлена.'
        }

        $service = Get-Service -Name $ServiceName
        if ($service.Status -ne [System.ServiceProcess.ServiceControllerStatus]::Stopped) {
            Stop-Service -Name $ServiceName
            $service.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Stopped, [TimeSpan]::FromSeconds(15))
        }
        $result = Invoke-CimMethod -InputObject $existing -MethodName Delete
        if ($result.ReturnValue -ne 0) {
            throw "Windows не удалила службу. Код: $($result.ReturnValue)"
        }
        Write-Host 'Автозапуск удалён. Для ручного запуска используй preset2_example.cmd.' -ForegroundColor Green
        exit 0
    }

    if (-not (Test-Path -LiteralPath $EnginePath -PathType Leaf) -or
        -not (Test-Path -LiteralPath $PresetPath -PathType Leaf)) {
        throw 'Положи все файлы этого комплекта в папку zapret-winws рядом с winws2.exe и preset2_example.cmd.'
    }

    if ($existing) {
        if (-not (Test-EngineCommandLine $existing.PathName)) {
            throw 'Служба Zapret2Auto уже существует и указывает на другую папку. Сначала удали прежнюю службу.'
        }
        Set-Service -Name $ServiceName -StartupType Automatic
        Write-Host 'Эта служба уже установлена. Автоматический запуск включён, сохранённые параметры оставлены прежними.' -ForegroundColor Yellow
        Write-Host 'Для переноса новых параметров сначала запусти REMOVE_PRESET2_AUTOSTART.cmd, затем установку заново.'
        Get-Service -Name $ServiceName | Format-Table Status, Name, DisplayName -AutoSize
        exit 0
    }

    $engines = @(Get-LocalEngineProcess)
    if ($engines.Count -eq 0) {
        Write-Host 'Запускаю preset2_example.cmd для получения его параметров...'
        Start-Preset
        $deadline = [DateTime]::UtcNow.AddSeconds(12)
        do {
            Start-Sleep -Milliseconds 300
            $engines = @(Get-LocalEngineProcess)
        } while ($engines.Count -eq 0 -and [DateTime]::UtcNow -lt $deadline)
    }
    if ($engines.Count -ne 1) {
        throw "Нужен один запущенный winws2.exe из этой папки. Найдено: $($engines.Count). Проверь ручной запуск preset2_example.cmd."
    }

    $engine = $engines[0]
    $commandLine = $engine.CommandLine
    if (-not (Test-EngineCommandLine $commandLine)) {
        throw 'Не удалось получить полную команду запуска winws2.exe. Установка отменена.'
    }
    $otherServices = @(Get-CimInstance Win32_Service -Filter "ProcessId=$($engine.ProcessId)")
    if ($otherServices.Count -ne 0) {
        throw "Этот winws2.exe уже запущен другой службой: $($otherServices[0].Name). Второй автозапуск создавать не нужно."
    }

    $created = $false
    $manualStopped = $false
    try {
        New-Service -Name $ServiceName -DisplayName 'Zapret 2 Auto (preset2)' `
            -Description 'Preset2Autostart: saved command line of the working winws2.exe.' `
            -BinaryPathName $commandLine -StartupType Automatic | Out-Null
        $created = $true

        # Replace only the single engine whose command line was saved.
        Stop-Process -Id $engine.ProcessId -Force
        $manualStopped = $true
        Wait-Process -Id $engine.ProcessId -Timeout 5 -ErrorAction SilentlyContinue

        Start-Service -Name $ServiceName
        $service = Get-Service -Name $ServiceName
        $service.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Running, [TimeSpan]::FromSeconds(15))
        Start-Sleep -Milliseconds 1000
        $service.Refresh()
        if ($service.Status -ne [System.ServiceProcess.ServiceControllerStatus]::Running) {
            throw 'Служба завершилась сразу после запуска.'
        }
    }
    catch {
        $installError = $_.Exception.Message
        if ($created) {
            try {
                Stop-Service -Name $ServiceName -ErrorAction SilentlyContinue
                $failedService = Get-NativeService
                if ($failedService -and (Test-EngineCommandLine $failedService.PathName)) {
                    $deleteResult = Invoke-CimMethod -InputObject $failedService -MethodName Delete
                    if ($deleteResult.ReturnValue -ne 0) {
                        Write-Warning "Откат удаления службы: код $($deleteResult.ReturnValue). Используй файл REMOVE_PRESET2_AUTOSTART.cmd."
                    }
                }
            }
            catch {
                Write-Warning "Не удалось полностью отменить установку: $($_.Exception.Message)"
            }
        }
        if ($manualStopped) {
            try {
                Start-Preset
                Write-Host 'Повторно запущен прежний preset2_example.cmd. Проверь его окно.' -ForegroundColor Yellow
            }
            catch {
                Write-Warning 'Запусти preset2_example.cmd вручную.'
            }
        }
        throw "Не удалось запустить службу. $installError"
    }

    Write-Host ''
    Write-Host 'Готово: служба работает и будет запускаться при включении Windows.' -ForegroundColor Green
    Write-Host "Папка: $Root"
    Write-Host 'Не перемещай эту папку. Вручную запускать preset2_example.cmd больше не нужно.'
    Write-Host 'Проверь WhatsApp сейчас и после следующей перезагрузки.'
    Get-Service -Name $ServiceName | Format-Table Status, Name, DisplayName -AutoSize
    exit 0
}
catch {
    Write-Host ''
    Write-Host ('ОШИБКА: ' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
